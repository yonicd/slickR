# texPreview 1.3.2
* Fix rotation LaTeX library used for rotation in the internal template.

# texPreview 1.3.1
* Fix path normalization to OS agnostic.

# texPreview 1.3.0

* Change names of function from camelcase to underscore and soft depreciate the camelcase
  - Old: texPreview, buildUsepackage, getTexPackages, texAddin
  - New: tex_preview, build_usepackage, get_texpackages, tex_addin

# texPreview 1.1.5

* fix viewer issue to keep new pages in internal viewer


# texPreview 1.1.4

* Added a `NEWS.md` file to track changes to the package.
* Added pagination of preview outputs in the `Rstudio` internal viewer.
