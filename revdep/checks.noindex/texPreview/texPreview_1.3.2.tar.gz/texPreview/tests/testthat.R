library(testthat)
library(texPreview)
test_check("texPreview")
